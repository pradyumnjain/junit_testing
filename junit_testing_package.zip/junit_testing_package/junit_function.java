package junit_testing_package;

public class junit_function {
	public int add_num(int num1,int num2) {
		return num1+num2;
	}
	
	public String addstring(String s1,String s2) {
		return s1+s2;
	}
}
